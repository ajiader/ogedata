<?php exit;?>1407122108|admin|你好
1407122356|scdh001|你好
