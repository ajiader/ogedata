<?php defined('IN_DESTOON') or exit('Access Denied');?><div class="footerdv">
<div class="ftct">
    <div class="ymbg"></div>
        <div class="zddh"><span>站点导航</span><p><a href="http://www.ogedata.com/aboutus.html" target="_blank">关于我们</a></p><p><a href="http://url.cn/OqkNO4" target="_blank">联系我们</a></p><p><a href="http://www.ogedata.com/news/" target="_blank">石油资讯</a></p><p><a href="http://www.ogedata.com/Links.html" target="_blank">申请友链</a></p></div>
        <div class="zddh hzhb"><span>合作伙伴</span><p><a href="http://www.ogedata.com/brand/show.php?itemid=81" target="_blank"><img src="/file/upload/201409/24/17-05-52-11-1.jpg" alt="中海油" /></a><a href="http://www.ogedata.com/brand/show.php?itemid=79" target="_blank"><img src="/file/upload/201409/11/17-38-33-92-1.jpg" alt="中石油" /></a><a href="http://www.ogedata.com/brand/show.php?itemid=80" target="_blank"><img src="/file/upload/201409/11/17-40-19-52-1.jpg" alt="中石化" /></a><a href="http://www.ogedata.com/brand/show.php?itemid=82" target="_blank"><img src="/file/upload/201410/14/15-29-02-32-1.jpg" alt="延长石油" /></a><a href="#" target="_blank"><img src="<?php echo DT_SKIN;?>/images/hbpic4.gif" alt="" /></a><a href="#" target="_blank"><img src="<?php echo DT_SKIN;?>/images/hbpic5.gif" /></a></p></div>
        <div class="zddh"><span>订阅资讯</span><p></a><a href="http://www.ogedata.com/sitemap.html" target="_blank"><img src="<?php echo DT_SKIN;?>/images/dy3.gif" alt="网站地图"/></a><a href="http://weibo.com/u/5268290179" target="_blank" rel="nofollow"><img src="http://www.ogedata.com/file/upload/201410/16/11-31-13-51-1.jpg" alt="新浪微博" /></a><script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F03ab8db179162eb6d7e2cde351577992' type='text/javascript'%3E%3C/script%3E"));
</script></p></div>
<div style="clear:both; text-align:center; padding:20px 0;"><a href="http://www.ogedata.com/" target="_blank"><span style="color: rgb(255, 255, 255);">油气设备数据网</span></a>&nbsp;&nbsp;&nbsp;<font color="#FFFFFF">蜀ICP备14023545号-1</font>&nbsp;&nbsp;&nbsp;<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1253333894'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s5.cnzz.com/z_stat.php%3Fid%3D1253333894%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
        <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F32f99be3cea49a11f0824a3ea83d545b' type='text/javascript'%3E%3C/script%3E"));
</script></div>
    </div>
</div>
<div id="back2top" class="back2top"><a href="javascript:void(0);" title="返回顶部">&nbsp;</a></div>
<script type="text/javascript">
<?php if($destoon_task) { ?>
show_task('<?php echo $destoon_task;?>');
<?php } else { ?>
<?php include DT_ROOT.'/api/task.inc.php';?>
<?php } ?>
<?php if($lazy) { ?>$(function(){$("img").lazyload();});<?php } ?>
$('#back2top').click(function() {
$("html, body").animate({scrollTop:0}, 200);
});
</script>
</body>
</html>