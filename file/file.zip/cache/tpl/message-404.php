<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<div class="m">
<br/>
<div class="title"><img src="<?php echo DT_SKIN;?>image/warn.gif" align="absmiddle"/> 对不起，您查找的页面不存在，以下信息有没有您需要的？</div>
<br/><br/><br/>
</div>
<div class="m">
<div class="m_l f_l">
<div class="box_head"><div><span class="f_r"><a href="<?php echo $MODULE['5']['linkurl'];?>">更多&raquo;</a></span><a href="<?php echo $MODULE['5']['linkurl'];?>"><strong>供应产品</strong></a></div></div>
<div class="box_body thumb"><?php echo tag("moduleid=5&length=14&condition=status=3 and vip>0 and thumb<>''&pagesize=20&order=addtime desc&width=90&height=90&cols=5&target=_blank&template=thumb-table");?></div>
</div>
<div class="m_n f_l">&nbsp;</div>
<div class="m_r f_l">
<div class="box_head"><div><span class="f_r"><a href="<?php echo $MODULE['6']['linkurl'];?>">更多&raquo;</a></span><a href="<?php echo $MODULE['6']['linkurl'];?>"><strong>求购信息</strong></a></div></div>
<div class="box_body li_dot f_gray"><?php echo tag("moduleid=6&condition=status=3 and vip>0&pagesize=10&datetype=2&order=addtime desc&target=_blank");?>
</div>
<div class="b10">&nbsp;</div>
<div class="box_head"><div><span class="f_r"><a href="<?php echo $MODULE['4']['linkurl'];?>">更多&raquo;</a></span><a href="<?php echo $MODULE['4']['linkurl'];?>"><strong><?php echo VIP;?>企业</strong></a></div></div>
<div class="box_body li_dot f_gray"><?php echo tag("moduleid=4&condition=vip>0 and catids<>''&pagesize=10&order=userid desc&template=list-com");?>
</div>
</div>
</div>
<?php include template('footer');?>