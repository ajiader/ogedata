<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<script type="text/javascript">var sh = '<?php echo $MOD['linkurl'];?>search.php?catid=<?php echo $catid;?>';</script>
<div class="syct">
<div class="list_lf">
<div class="left_box">
<div class="pos">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <?php echo cat_pos($CAT, ' &raquo; ');?></div>
<?php if($CP) { ?>
<?php if(is_array($PPT)) { foreach($PPT as $p) { ?>
<div class="ppt">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="ppt_l" valign="top">按<?php echo $p['name'];?></td>
<td class="ppt_r" valign="top">
<?php if(is_array($p['options'])) { foreach($p['options'] as $o) { ?>
<a href="###" onclick="Go(sh+'&ppt_<?php echo $p['oid'];?>=<?php echo urlencode($o);?>');"><?php echo $o;?></a>&nbsp;|&nbsp;
<?php } } ?>
</td>
</tr>
</table>
</div>
<?php } } ?>
<div class="b10">&nbsp;</div>
<?php } ?>
<div class="catlist">
<?php if($tags) { ?><?php include template('list-cat', 'tag');?><?php } ?>
</div>
</div>
</div>
<div class="list_rg">
<div class="listrg">
<?php if($MOD['show_lcat']) { ?>
<div class="box_head">按分类浏览</div>
<div class="box_body">
<table width="100%" cellpadding="3">
<?php if(is_array($maincat)) { foreach($maincat as $k => $v) { ?>
<?php if($k%2==0) { ?><tr><?php } ?>
<td<?php if($v['catid']==$catid) { ?> class="f_b"<?php } ?>
><a href="<?php echo $MOD['linkurl'];?><?php echo $v['linkurl'];?>"><?php echo set_style($v['catname'],$v['style']);?></a><?php if(!$cityid) { ?> <span class="f_gray px10">(<?php echo $v['item'];?>)</span><?php } ?>
</td>
<?php if($k%2==1) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
    </div>
<?php } ?>
    <div class="listrg">
<?php if($MOD['page_lrecimg']) { ?>
<div class="box_head">推荐图文</div>
<div class="box_body thumb newsrgimg"><?php echo tag("moduleid=$moduleid&length=20&condition=status=3 and level=3 and thumb!=''&catid=$catid&pagesize=".$MOD['page_lrecimg']."&order=".$MOD['order']."&width=120&height=90&cols=2&target=_blank&template=thumb-table");?></div>
</div>
<?php } ?>
<?php if($MOD['page_lrec']) { ?>
    <div class="listrg">
<div class="box_head">推荐<?php echo $MOD['name'];?></div>
<div class="box_body li_dot"><?php echo tag("moduleid=$moduleid&condition=status=3 and level=1&catid=$catid&order=".$MOD['order']."&pagesize=".$MOD['page_lrec']."&target=_blank");?>
</div>
</div>
<?php } ?>
<?php if($MOD['page_lhits']) { ?>
    <div class="listrg">
<div class="box_head">点击排行</div>
<div class="box_body">
<div class="rank_list"><?php echo tag("moduleid=$moduleid&condition=status=3 and addtime>$today_endtime-30*86400&catid=$catid&order=hits desc&pagesize=".$MOD['page_lhits']."&target=_blank");?></div>
</div>
    </div>
<?php } ?>
</div>
</div>
<?php include template('footer');?>