<?php defined('IN_DESTOON') or exit('Access Denied');?><?php if($DT_QST) { ?>
<div style="padding:20px 10px 30px 30px;line-height:180%;">
<strong class="px14">抱歉，没有找到<?php if($kw) { ?>与“<span class="f_red"><?php echo $kw;?></span>” <?php } ?>
相关的内容。</strong>
<br/><br/>
&nbsp;<strong>建议您：</strong><br/>
&nbsp;&nbsp;&bull; 看看输入的文字是否有误<br/>
&nbsp;&nbsp;&bull; 去掉可能不必要的字词，如“的”、“什么”等<br/>
&nbsp;&nbsp;&bull; 调整更确切的关键词或搜索条件<br/>
</div>
<?php } ?>
