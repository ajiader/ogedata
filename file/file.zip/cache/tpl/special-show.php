<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header', $module);?>
<script type="text/javascript">var module_id= <?php echo $moduleid;?>,item_id=<?php echo $itemid;?>;</script>
<?php if($banner) { ?>
<div class="m"><a href="<?php echo $linkurl;?>"><img src="<?php echo $banner;?>" alt="<?php echo $title;?>"/></a></div>
<div class="m b10">&nbsp;</div>
<?php } ?>
<div class="m">
<div class="m_l f_l">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="320">
<?php echo tag("table=special_item&condition=specialid=$itemid and level=2 and thumb<>''&order=addtime desc&pagesize=3&width=320&height=200&target=_blank&template=slide");?>
</td>
<td width="10"></td>
<td valign="top">
<div class="headline">
<?php echo tag("table=special_item&condition=specialid=$itemid and level=5&order=addtime desc&pagesize=1&target=_blank&template=list-hl");?>
<?php echo tag("table=special_item&condition=specialid=$itemid and level=4&pagesize=2&order=addtime desc&target=_blank&template=list-hlr&cols=2");?>
</div>
<div class="b5"></div>
<div class="subline">
<?php echo tag("table=special_item&condition=specialid=$itemid and level=1&order=addtime desc&pagesize=5&datetype=2&target=_blank&class=b");?>
</div>
</td>
</tr>
</table>
</div>
<div class="m_n f_l">&nbsp;</div>
<div class="m_r f_l">
<div class="box_head"><div><strong><?php echo $MOD['name'];?>介绍</strong></div></div>
<div class="box_body">
<?php if($CP) { ?><?php include template('property', 'chip');?><?php } ?>
<div class="special_intro"><?php echo $content;?></div>
</div>
</div>
</div>
<?php if($cfg_photo) { ?>
<div class="m">
<div class="b10">&nbsp;</div>
<div class="box_head"><div><strong>图片报道</strong></div></div>
<div class="box_body">
<div class="thumb">
<?php echo tag("table=special_item&condition=specialid=$itemid and level=3 and thumb<>''&pagesize=$cfg_photo&length=20&order=addtime desc&width=120&height=90&cols=6&target=_blank&template=thumb-table", -2);?>
</div>
</div>
</div>
<?php } ?>
<?php if($cfg_video) { ?>
<div class="m">
<div class="b10">&nbsp;</div>
<div class="box_head"><div><strong>视频报道</strong></div></div>
<div class="box_body">
<div class="thumb">
<?php echo tag("table=special_item&condition=specialid=$itemid and level=6 and thumb<>''&pagesize=$cfg_video&length=20&order=addtime desc&width=120&height=90&cols=6&target=_blank&template=thumb-table", -2);?>
</div>
</div>
</div>
<?php } ?>
<?php if($cfg_type) { ?>
<div class="m">
<div class="special_box">
<table cellpadding="0" cellspacing="0" width="990">
<?php if(is_array($TYPE)) { foreach($TYPE as $k => $v) { ?>
<?php if($k%3==0) { ?><tr><?php } ?>
<td valign="top" width="320">
<div class="b10"></div>
<div class="box_head"><span class="f_r"><a href="<?php echo $v['linkurl'];?>">更多&raquo;</a></span><strong><?php echo $v['typename'];?></strong></div>
<div class="box_body li_dot f_gray"><?php echo tag("table=special_item&condition=specialid=$itemid and typeid=".$v['typeid']."&order=addtime desc&pagesize=$cfg_type&datetype=2&target=_blank", -2);?></div>
</td>
<td width="10">&nbsp;</td>
<?php if($k%3==2) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
</div>
<?php } ?>
<div class="m">
<div class="b10"> </div>
<div class="box_body" style="padding:0;">
<?php include template('comment', 'chip');?>
</div>
</div>
<?php include template('footer');?>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"slide":{"type":"slide","bdImg":"0","bdPos":"left","bdTop":"100"}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>