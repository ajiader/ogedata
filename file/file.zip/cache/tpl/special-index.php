<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<div class="syct" style="padding-top:10px;">
<div class="bsdlf">
<?php if($MOD['page_icat']) { ?>
<?php if(is_array($maincat)) { foreach($maincat as $i => $c) { ?>
<?php if($i) { ?><div class="b10"></div><?php } ?>

<div class="box_head"><span class="f_r"><a href="<?php echo $MOD['linkurl'];?><?php echo $c['linkurl'];?>">更多&raquo;</a></span><strong><?php echo $c['catname'];?></strong></div>
<div class="box_body">
<div class="thumb"><?php echo tag("moduleid=$moduleid&catid=".$c['catid']."&areaid=$cityid&condition=status=3 and thumb<>''&order=".$MOD['order']."&length=20&width=120&height=90&pagesize=".$MOD['page_icat']."&cols=4&lazy=$lazy&template=thumb-table");?></div>
</div>
<?php } } ?>
<?php } ?>
</div>
<div class="list_rg">
    
<div class="box_head"><div><strong>按分类浏览</strong></div></div>
<div class="box_body">
<table width="100%" cellpadding="3">
<?php if(is_array($maincat)) { foreach($maincat as $k => $v) { ?>
<?php if($k%2==0) { ?><tr><?php } ?>
<td><a href="<?php echo $MOD['linkurl'];?><?php echo $v['linkurl'];?>"><?php echo set_style($v['catname'],$v['style']);?></a><?php if(!$cityid) { ?> <span class="f_gray px10">(<?php echo $v['item'];?>)</span><?php } ?>
</td>
<?php if($k%2==1) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
<div class="b10 c_b"> </div>
<div class="box_head"><div><strong>点击排行</strong></div></div>
<div class="box_body">
<div class="rank_list"><?php echo tag("moduleid=$moduleid&condition=status=3 and addtime>$today_endtime-60*86400&areaid=$cityid&order=hits desc&pagesize=10");?></div>
</div>
</div>
</div>
<?php include template('footer');?>