<?php defined('IN_DESTOON') or exit('Access Denied');?><?php if(is_array($tags)) { foreach($tags as $k => $t) { ?>
<div class="list" id="item_<?php echo $t['itemid'];?>">
<table>
<tr align="center">
<td width="100"><div><a href="<?php echo $t['linkurl'];?>" target="_blank"><img src="<?php echo imgurl($t['thumb']);?>" width="80" height="80" alt="<?php echo $t['alt'];?>"/></a></div></td>
<td align="left">
<ul>
<li><a href="<?php echo $t['linkurl'];?>" target="_blank"><strong class="px14"><?php echo $t['title'];?></strong></a></li>
<li class="f_gray">地址:<?php echo $t['address'];?></li>
<li class="f_gray">主办:<?php echo $t['sponsor'];?></li>
<li class="px11"><?php echo timetodate($t['fromtime'], 3);?> ~ <?php echo timetodate($t['totime'], 3);?></li>
</ul>
</td>
<td width="160" class="f_gray">[<?php echo $t['city'];?>]</td>
<td width="100"><img src="<?php echo DT_STATIC;?>file/image/process_<?php echo get_process($t['fromtime'], $t['totime']);?>.gif"/></td>
</tr>
</table>
</div>
<?php } } ?>
<?php if($showpage && $pages) { ?><div class="pages"><?php echo $pages;?></div><?php } ?>
