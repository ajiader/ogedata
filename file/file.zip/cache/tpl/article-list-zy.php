<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<script type="text/javascript">var sh = '<?php echo $MOD['linkurl'];?>search.php?catid=<?php echo $catid;?>';</script>
<div class="syct">
<div class="list_lf">
<div class="left_box">
<div class="pos">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <?php echo cat_pos($CAT, ' &raquo; ');?></div>
<?php if($CP) { ?>
<?php if(is_array($PPT)) { foreach($PPT as $p) { ?>
<div class="ppt">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="ppt_l" valign="top">按<?php echo $p['name'];?></td>
<td class="ppt_r" valign="top">
<?php if(is_array($p['options'])) { foreach($p['options'] as $o) { ?>
<a href="###" onclick="Go(sh+'&ppt_<?php echo $p['oid'];?>=<?php echo urlencode($o);?>');"><?php echo $o;?></a>&nbsp;|&nbsp;
<?php } } ?>
</td>
</tr>
</table>
</div>
<?php } } ?>
<div class="b10">&nbsp;</div>
<?php } ?>
        
        <div class="sysous symgbt" style="padding:20px 0 0 80px;">
            <div class="sousuodv cxdv_w">
            <form action="/zhuanye/search.php" method="get">
                <div class="dv1"><input type="text" style="width:460px;" onfocus="this.value='';this.style.color='#333333'" style="color:#999999;" value="请输入想查询的名词" class="ip2" name="kw"></div>
                <input type="submit" value="搜索" class="ip3" name="ssbtn"> 
                </form>
            </div>
        </div>
        
        
        <div style="height:30px; line-height:30px; border-bottom:1px #d9d9d9 solid; margin:0 20px; font-size:16px; font-weight:bold; padding:20px 0 0 0;"><span style="border-bottom:2px #5fc4f3 solid; padding:0 15px; float:left;">英文名词</span><span style="float:right;">汉语对照</span></div>
<div class="catlist">
<?php if($tags) { ?><?php include template('list-cat-zy', 'tag');?><?php } ?>
</div>
</div>
</div>
<div class="list_rg">
<div class="listrg">
<?php if($MOD['show_lcat']) { ?>
<div class="box_head">按分类浏览</div>
<div class="box_body">
<table width="100%" cellpadding="3">
<?php if(is_array($maincat)) { foreach($maincat as $k => $v) { ?>
<?php if($k%2==0) { ?><tr><?php } ?>
<td<?php if($v['catid']==$catid) { ?> class="f_b"<?php } ?>
><a href="<?php echo $MOD['linkurl'];?><?php echo $v['linkurl'];?>"><?php echo set_style($v['catname'],$v['style']);?></a><?php if(!$cityid) { ?> <span class="f_gray px10">(<?php echo $v['item'];?>)</span><?php } ?>
</td>
<?php if($k%2==1) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
    </div>
<?php } ?>
<?php if($MOD['page_lrec']) { ?>
    <div class="listrg">
<div class="box_head">推荐<?php echo $MOD['name'];?></div>
<div class="box_body li_dot"><?php echo tag("moduleid=$moduleid&condition=status=3 and level=1&catid=$catid&order=".$MOD['order']."&pagesize=".$MOD['page_lrec']."&target=_blank");?>
</div>
</div>
<?php } ?>
<?php if($MOD['page_lhits']) { ?>
    <div class="listrg">
<div class="box_head">点击排行</div>
<div class="box_body">
<div class="rank_list"><?php echo tag("moduleid=$moduleid&condition=status=3 and addtime>$today_endtime-30*86400&catid=$catid&order=hits desc&pagesize=".$MOD['page_lhits']."&target=_blank");?></div>
</div>
    </div>
<?php } ?>
</div>
</div>
<?php include template('footer');?>