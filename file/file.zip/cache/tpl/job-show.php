<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<script type="text/javascript">var module_id= <?php echo $moduleid;?>,item_id=<?php echo $itemid;?>,content_id='content',img_max_width=<?php echo $MOD['max_width'];?>;</script>
<div class="m">
<div class="m_l f_l">
<div class="left_box">
<div class="pos">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <?php echo cat_pos($CAT, ' &raquo; ');?> &raquo; 招聘详情</div>
<h1 class="title" id="title"><?php echo $title;?></h1>
<div class="info"><span class="f_r"><img src="<?php echo DT_SKIN;?>image/zoomin.gif" width="16" height="16" alt="放大字体" class="c_p" onclick="fontZoom('+');"/>&nbsp;&nbsp;<img src="<?php echo DT_SKIN;?>image/zoomout.gif" width="16" height="16"  alt="缩小字体" class="c_p" onclick="fontZoom('-');"/></span>
发布日期：<?php echo $adddate;?>
&nbsp;&nbsp;浏览次数：<span id="hits"><?php echo $hits;?></span>
</div>
<div class="pd20" >
<table cellpadding="6" cellspacing="1" width="100%" bgcolor="#DDDDDD">
<tr bgcolor="#FFFFFF">
<td width="80">&nbsp;行业</td>
<td width="230">&nbsp;<?php echo $CATEGORY[$parentid]['catname'];?></td>
<td width="80">&nbsp;职位</td>
<td width="230">&nbsp;<?php echo $CATEGORY[$catid]['catname'];?></td>
</tr>
<tr bgcolor="#FFFFFF">
<td>&nbsp;招聘部门</td>
<td>&nbsp;<?php echo $department;?></td>
<td>&nbsp;招聘人数</td>
<td>&nbsp;<?php if($total) { ?><?php echo $total;?>人<?php } else { ?>若干<?php } ?>
</td>
</tr>
<tr bgcolor="#FFFFFF">
<td>&nbsp;工作地区</td>
<td>&nbsp;<?php echo area_pos($areaid, '');?></td>
<td>&nbsp;工作性质</td>
<td>&nbsp;<?php echo $TYPE[$type];?></td>
</tr>
<tr bgcolor="#FFFFFF">
<td>&nbsp;性别要求</td>
<td>&nbsp;<?php echo $GENDER[$gender];?></td>
<td>&nbsp;婚姻要求</td>
<td>&nbsp;<?php echo $MARRIAGE[$marriage];?></td>
</tr>
<tr bgcolor="#FFFFFF">
<td>&nbsp;学历要求</td>
<td>&nbsp;<?php echo $EDUCATION[$education];?></td>
<td>&nbsp;工作经验</td>
<td>&nbsp;<?php if($experience) { ?><?php echo $experience;?>年以上<?php } else { ?>不限<?php } ?>
</td>
</tr>
<tr bgcolor="#FFFFFF">
<td>&nbsp;年龄要求</td>
<td>&nbsp;<?php if($minage && $maxage) { ?><?php echo $minage;?>-<?php echo $maxage;?>岁<?php } else if($minage) { ?><?php echo $minage;?>岁以上<?php } else if($maxage) { ?><?php echo $maxage;?>岁以内<?php } else { ?>不限年龄<?php } ?>
</td>
<td>&nbsp;待遇水平</td>
<td>&nbsp;<?php if($minsalary && $maxsalary) { ?><?php echo $minsalary;?>-<?php echo $maxsalary;?><?php echo $DT['money_unit'];?>/月<?php } else if($minsalary) { ?><?php echo $minsalary;?><?php echo $DT['money_unit'];?>/月以上<?php } else if($maxsalary) { ?><?php echo $maxsalary;?><?php echo $DT['money_unit'];?>/月以内<?php } else { ?>面议<?php } ?>
</td>
</tr>
<tr bgcolor="#FFFFFF">
<td>&nbsp;更新日期</td>
<td>&nbsp;<?php echo $editdate;?></td>
<td>&nbsp;有效期至</td>
<td>&nbsp;<?php echo $todate;?><?php if($expired) { ?><span class="f_red">[已过期]</span><?php } ?>
</td>
</tr>
</table>
</div>
<div class="left_head">职位描述</div>
<div class="content" id="content"><?php echo $content;?></div>
<div class="b10">&nbsp;</div>
<?php if($CP) { ?><?php include template('property', 'chip');?><?php } ?>
<br/>
<?php if($username) { ?>
<center>
<img src="<?php echo DT_SKIN;?>image/job_apply.gif" width="160" height="37" alt="申请该职位" class="c_p" onclick="Go('<?php echo $MOD['linkurl'];?><?php echo rewrite('apply.php?itemid='.$itemid);?>');"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="<?php echo DT_SKIN;?>image/job_fav.gif" width="160" height="37" alt="收藏该职位" class="c_p" onclick="SendFav();"/>
<?php } ?>
</center>
<br/>
<?php if($com_intro) { ?>
<div class="left_head">公司介绍</div>
<div class="content"><?php echo $com_intro;?></div>
<div class="b10">&nbsp;</div>
<?php } ?>
<center>
[ <a href="<?php echo $MOD['linkurl'];?>search.php" rel="nofollow"><?php echo $MOD['name'];?>搜索</a> ]&nbsp;
[ <a href="javascript:SendFav();">加入收藏</a> ]&nbsp;
[ <a href="javascript:SendPage();">告诉好友</a> ]&nbsp;
[ <a href="javascript:Print();">打印本文</a> ]&nbsp;
[ <a href="javascript:window.close()">关闭窗口</a> ]
</center>
<br/>
<?php include template('comment', 'chip');?>
<br/>
</div>
</div>
<div class="m_n f_l">&nbsp;</div>
<div class="m_r f_l">
<div class="contact_head">联系方式</div>
<div class="contact_body" id="contact"><?php include template('contact', 'chip');?></div>
<div class="b10">&nbsp;</div>
<div class="tab_head">
<ul>
<li class="tab_2" id="job_t_1" onmouseover="Tb(1, 2, 'job', 'tab');">职位搜索</li>
<li class="tab_1" id="job_t_2" onmouseover="Tb(2, 2, 'job', 'tab');">人才搜索</li>
</ul>
</div>
<div class="box_body">
<div id="job_c_1" style="display:">
<form action="<?php echo $MOD['linkurl'];?>search.php">
<input type="text" size="22" name="kw"/> 
<input type="submit" value="搜索"/>
<input type="button" value="高级" onclick="Go('<?php echo $MOD['linkurl'];?><?php echo rewrite('search.php?action=job');?>');"/>
</form>
</div>
<div id="job_c_2" style="display:none">
<form action="<?php echo $MOD['linkurl'];?>search.php">
<input type="hidden" name="action" value="resume"/>
<input type="text" size="22" name="kw"/> 
<input type="submit" value="搜索"/>
<input type="button" value="高级" onclick="Go('<?php echo $MOD['linkurl'];?><?php echo rewrite('search.php?action=resume');?>');"/>
</form>
</div>
</div>
<?php if($username) { ?>
<div class="b10">&nbsp;</div>
<div class="box_head"><div><strong>该企业其他招聘</strong></div></div>
<div class="box_body f_gray li_dot">
<?php echo tag("moduleid=$moduleid&condition=status=3 and username='$username'&pagesize=10&datetype=2&order=addtime desc", -2);?>
</div>
<?php } ?>
</div>
</div>
<?php if($content) { ?><script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/content.js"></script><?php } ?>
<?php include template('footer');?>