<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<div class="m">
<div style="padding:20px 300px 20px 50px;line-height:220%;">
&nbsp;<strong class="px16"><?php echo $head_title;?></strong><br/>
&nbsp;<span class="px14">您访问的公司尚未注册本站会员，无法查看详细信息，建议优先选择 <strong class="f_red"><?php echo VIP;?></strong> 会员</span><br/>
</div>
</div>
<?php include template('footer');?>