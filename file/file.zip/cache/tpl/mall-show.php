<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<script type="text/javascript">var module_id= <?php echo $moduleid;?>,item_id=<?php echo $itemid;?>,content_id='content',img_max_width=<?php echo $MOD['max_width'];?>;</script>
<div class="syct sypd">

    <?php include template('mall/search_top');?>
    
    
    <div class="dqwz_1">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <?php echo cat_pos($CAT, ' &raquo; ');?> &raquo;</div>
<?php if($filepaths) { ?>
    <div class="tytil">PDF资料下载</div>
    <div class="dowdv">
    <dl>
        <dt></dt>
            <dd class="dd1"><?php echo $title;?></dd>
            <dd class="dd2"></dd>
        </dl>
        <div class="downloadbtn"><a href="<?php echo $filepaths;?>" target="_blank">Download | 下载</a></div>
    </div>
<?php } ?>
    <div class="xzdetail"><?php echo $title;?></div>
    <div class="detaildv">
    <div class="dtpic"><img src="<?php echo str_replace('.middle.jpg', '', $albums['0']);?>" width="275" /></div>
        <div class="dtnr">
            <div class="nrty"><span class="sp1">件号</span><span class="sp2"><?php echo $jianhao;?></span></div>
            <div class="nrty"><span class="sp1">名称</span><span class="sp2"><?php echo $title;?></span></div>
            <div class="nrty"><span class="sp1">重量</span><span class="sp2"><?php echo $weight;?>千克</span></div>
            <div class="nrty"><span class="sp1">尺寸</span><span class="sp2"><?php echo $size;?></span></div>
            <div class="nrty"><span class="sp1">品牌</span><span class="sp2"><?php if($brand_id) { ?> <?php $brandRow = getBrandName($brand_id); ?> <a href="<?php echo $MODULE['13']['linkurl'];?><?php echo $brandRow['linkurl'];?>" target="_blank"><?php echo $brandRow['title'];?></a> <?php } else { ?>未填写<?php } ?>
</span></div>
            <div class="zx_wen"><a href="javascript:void(0)" onclick="kefulink()">在线询问</a></div>
            <div class="xwa" style="display: none;"><?php if($status == 3 && $amount > 0) { ?>

<div id="cart_tip" style="display:none;">
<p><img src="<?php echo DT_SKIN;?>image/close.gif" alt="关闭" width="17" height="12" onclick="Dh('cart_tip');"/>提示信息</p>
<div>已成功添加到购物车！购物车里已有 <span id="cart_num">0</span> 种商品</div>
<center>
<input type="button" value="再逛逛" onclick="Dh('cart_tip');"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="去结算" onclick="Go('<?php echo $MOD['linkurl'];?>cart.php');"/>
</center>
</div>
<img src="<?php echo DT_SKIN;?>image/btn_tobuy.gif" style="display: none;" alt="立即购买" class="c_p" onclick="BuyNow();"/>
&nbsp;
<img src="<?php echo DT_SKIN;?>image/btn_addcart.gif" style="display: none;" alt="加入购物车" class="c_p" onclick="AddCart();"/>

<?php } else { ?>
<strong class="f_red">该商品已下架</strong></td>

<?php } ?>
</div>
        </div>
        <div class="ggdv" id="PAGE_AD_996076"></div>
        <div class="clear"></div>
    </div>
  <div class="xzdetail">产品详细说明</div>
<?php if($CP) { ?>
<div style="border:#999999 1px dashed; padding:6px 10px; margin:8px 0;">
 <p> <strong>扩展属性：</strong></p><br />
<p><?php if(is_array($options)) { foreach($options as $o) { ?> <span style="color:#333"><?php echo $o['name'];?>: <?php echo $values[$o['oid']];?></span> &nbsp;<?php } } ?></p>
</div>
  <?php } ?>
    <div class="detailnr">
    <?php echo $content;?>
    </div>
     <?php if($brandRow) { ?>
    <div style="border:#999999 1px dashed;padding:6px 10px; margin:8px 0;">
 <p> <strong>品牌供货商联系方式：</strong></p><br />
 <p><?php if($brandRow['telephone']) { ?>座机：<?php echo $brandRow['telephone'];?><?php } ?>
 <?php if($brandRow['mobile']) { ?>手机：<?php echo $brandRow['mobile'];?><?php } ?>
</p>
 </div><?php } ?>
    <div class="xzdetail">Link URL</div>
    <div><input type="text" class="linkurl" value="<?php echo $linkurl;?>" /></div>
</div>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/album.js"></script>
<?php if($content) { ?><script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/content.js"></script><?php } ?>
<script type="text/javascript">
var mallurl = '<?php echo $MOD['linkurl'];?>';
var mallid = <?php echo $itemid;?>;
var n_c = <?php echo $comments;?>;
var n_o = <?php echo $orders;?>;
//var c_c = Dd('c_comment').innerHTML;
//var c_o = Dd('c_order').innerHTML;
var s_s = {'1':0,'2':0,'3':0};
var m_l = {
no_comment:'暂无评论',
no_order:'暂无交易',
no_goods:'商品不存在或已下架',
no_self:'不能添加自己的商品',
lastone:''
};
</script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/mall.js"></script>
<script type="text/javascript">
<?php if($p1) { ?>addE(1);<?php } ?>
<?php if($p2) { ?>addE(2);<?php } ?>
<?php if($p3) { ?>addE(3);<?php } ?>
if(window.location.href.indexOf('#') != -1) {
var t = window.location.href.split('#');
try {Mshow(t[1]);} catch(e) {}
}
</script>
<?php include template('footer');?>
<!-广告位>
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
BAIDU_CLB_fillSlotAsync('996076', 'PAGE_AD_996076');
</script>