<?php defined('IN_DESTOON') or exit('Access Denied');?><ul>
<?php if(is_array($tags)) { foreach($tags as $i => $t) { ?>
<li class="catlist_li"><?php if($datetype) { ?><span class="f_r px11 f_gray" style="color:#333333; font-size:12px; font-family:宋体;"><?php echo $t['introduce'];?></span><?php } ?>
<a href="<?php echo $t['linkurl'];?>" target="_blank" title="<?php echo $t['alt'];?>"><?php echo $t['title'];?></a></li>
<?php if($cols && $i && $i%$cols==($cols-1)) { ?><li class="catlist_sp">&nbsp;</li><?php } ?>
<?php } } ?>
</ul>
<?php if($showpage && $pages) { ?><div class="pages"><?php echo $pages;?></div><?php } ?>
