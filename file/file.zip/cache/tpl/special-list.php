<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<script type="text/javascript">var sh = '<?php echo $MOD['linkurl'];?>search.php?catid=<?php echo $catid;?>';</script>
<div class="m">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" class="left_menu">
<ul>
<li class="<?php if($CAT['child']) { ?>left_menu_on<?php } else { ?>left_menu_li<?php } ?>
"><a href="<?php echo $MOD['linkurl'];?>">按分类浏览</a></li>
<?php if(is_array($maincat)) { foreach($maincat as $k => $v) { ?>
<li class="<?php if($v['catid']==$catid) { ?>left_menu_on<?php } else { ?>left_menu_li<?php } ?>
"><a href="<?php echo $MOD['linkurl'];?><?php echo $v['linkurl'];?>"><?php if($v['child']) { ?>+<?php } else { ?>-<?php } ?>
<?php echo set_style($v['catname'],$v['style']);?><?php if(!$cityid) { ?>(<?php echo $v['item'];?>)<?php } ?>
</a></li>
<?php } } ?>
</ul>
</td>
<td valign="top">
<div class="left_box">
<div class="pos">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <?php echo cat_pos($CAT, ' &raquo; ');?></div>
<?php if($CP) { ?>
<?php if(is_array($PPT)) { foreach($PPT as $p) { ?>
<div class="b10">&nbsp;</div>
<div class="ppt">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="ppt_l" valign="top">按<?php echo $p['name'];?></td>
<td class="ppt_r" valign="top">
<?php if(is_array($p['options'])) { foreach($p['options'] as $o) { ?>
<a href="###" onclick="Go(sh+'&ppt_<?php echo $p['oid'];?>=<?php echo urlencode($o);?>');"><?php echo $o;?></a>&nbsp;|&nbsp;
<?php } } ?>
</td>
</tr>
</table>
</div>
<?php } } ?>
<?php } ?>
<div class="pd10">
<div class="thumb"><?php if($tags) { ?><?php include template('list-'.$module, 'tag');?><?php } ?>
</div>
</div>
</div>
</td>
</tr>
</table>
</div>
<?php include template('footer');?>