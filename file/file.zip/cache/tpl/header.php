<?php defined('IN_DESTOON') or exit('Access Denied');?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=<?php echo DT_CHARSET;?>"/>
<title><?php if($seo_title) { ?><?php echo $seo_title;?><?php } else { ?><?php if($head_title) { ?><?php echo $head_title;?><?php echo $DT['seo_delimiter'];?><?php } ?>
<?php if($city_sitename) { ?><?php echo $city_sitename;?><?php } else { ?><?php echo $DT['sitename'];?><?php } ?>
<?php } ?>
</title>
<?php if($head_keywords) { ?>
<meta name="keywords" content="<?php echo $head_keywords;?>"/>
<?php } ?>
<?php if($head_description) { ?>
<meta name="description" content="<?php echo $head_description;?>"/>
<?php } ?>
<?php if($head_mobile) { ?>
<meta http-equiv="mobile-agent" content="format=xhtml; url=<?php echo $head_mobile;?>" /> 
<meta http-equiv="mobile-agent" content="format=html5; url=<?php echo $head_mobile;?>" />
<?php } ?>
<meta name="generator" content="油气设备数据平台 - www.ogedata.com"/>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo DT_STATIC;?>favicon.ico"/>
<link rel="bookmark" type="image/x-icon" href="<?php echo DT_STATIC;?>favicon.ico"/>
<?php if($head_canonical) { ?>
<link rel="canonical" href="<?php echo $head_canonical;?>"/>
<?php } ?>
<?php if($EXT['archiver_enable']) { ?>
<link rel="archives" title="<?php echo $DT['sitename'];?>" href="<?php echo $EXT['archiver_url'];?>"/>
<?php } ?>
<link rel="stylesheet" type="text/css" href="<?php echo DT_SKIN;?>sy_css.css"/>
<?php if($moduleid>4) { ?><link rel="stylesheet" type="text/css" href="<?php echo DT_SKIN;?><?php echo $module;?>.css"/><?php } ?>
<?php if($CSS) { ?>
<?php if(is_array($CSS)) { foreach($CSS as $css) { ?>
<link rel="stylesheet" type="text/css" href="<?php echo DT_SKIN;?><?php echo $css;?>.css"/>
<?php } } ?>
<?php } ?>
<!--[if lte IE 6]>
<link rel="stylesheet" type="text/css" href="<?php echo DT_SKIN;?>ie6.css"/>
<![endif]-->
<?php if(!DT_DEBUG) { ?><script type="text/javascript">window.onerror=function(){return true;}</script><?php } ?>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/sy_select.js"></script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>lang/<?php echo DT_LANG;?>/lang.js"></script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/config.js"></script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/jquery.js"></script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/common.js"></script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/sethome.js"></script>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/page.js"></script>
<?php if($lazy) { ?><script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/jquery.lazyload.js"></script><?php } ?>
<?php if($JS) { ?>
<?php if(is_array($JS)) { foreach($JS as $js) { ?>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/<?php echo $js;?>.js"></script>
<?php } } ?>
<?php } ?>
<?php $searchid = ($moduleid > 3 && $MODULE[$moduleid]['ismenu'] && !$MODULE[$moduleid]['islink']) ? $moduleid : 5;?>
<script type="text/javascript">
<?php if($head_mobile && $EXT['wap_goto']) { ?>
GoMobile('<?php echo $head_mobile;?>');
<?php } ?>
var searchid = <?php echo $searchid;?>;
<?php if($itemid && $DT['anticopy']) { ?>
document.oncontextmenu=function(e){return false;};
document.onselectstart=function(e){return false;};
<?php } ?>
</script>
</head>
<body>
<!-- header<start>-->
<div class="xg_top_dv">
<div class="syct">
    <div class="logindv" id="destoon_member"></div>
        <div class="jrscdv"><a onclick="SetHome(this,window.location);" href="javascript:void(0)">设为首页</a>|<a onclick="addFavorite2()">加入收藏</a></div>
    </div>
</div>
<div class="xg_logodv">
<div class="syct">
        <div class="lflogo"><a href="<?php echo $MODULE['1']['linkurl'];?>"></a></div>
        <div class="rgsearch"><?php include template('mall/search_top');?></div>
    </div>
</div>
<div class="xg_menu">
<div class="menuct">
    <div class="navdv"><a href="<?php echo $MODULE['1']['linkurl'];?>" <?php if($moduleid<4) { ?>class="selected"<?php } ?>
>首页</a><a href="<?php echo $MODULE['13']['linkurl'];?>" <?php if($moduleid==13) { ?>class="selected"<?php } ?>
>品牌</a><a href="<?php echo $MODULE['8']['linkurl'];?>" <?php if($moduleid==8) { ?>class="selected"<?php } ?>
>展会</a><a href="<?php echo $MODULE['11']['linkurl'];?>" <?php if($moduleid==11) { ?>class="selected"<?php } ?>
>专题</a><a href="<?php echo $MODULE['9']['linkurl'];?>" <?php if($moduleid==9) { ?>class="selected"<?php } ?>
>招聘</a><a href="<?php echo $MODULE['7']['linkurl'];?>" <?php if($moduleid==7) { ?>class="selected"<?php } ?>
>行情</a></div>
        <div class="cutdv">设备</div>
        <div class="sbdv"><a href="<?php echo $MODULE['16']['linkurl'];?>list.php?catid=4" target="_blank">井口装置</a><a href="<?php echo $MODULE['16']['linkurl'];?>list.php?catid=140"  target="_blank">流控产品</a><a href="<?php echo $MODULE['16']['linkurl'];?>list.php?catid=133" target="_blank">防喷器材</a><a href="http://www.ogedata.com/mall/" target="_blank">全部产品</a></div>
        <div class="cutdv">资讯</div>
        <div class="sbdv"><a href="<?php echo $MODULE['21']['linkurl'];?>list.php?catid=69" target="_blank">国际新闻</a><a href="<?php echo $MODULE['21']['linkurl'];?>list.php?catid=77" target="_blank">国内新闻</a><a href="<?php echo $MODULE['21']['linkurl'];?>list.php?catid=164" target="_blank">石油技术</a><a href="<?php echo $MODULE['21']['linkurl'];?>" <?php if($moduleid==21) { ?>class="selected"<?php } ?>
>查看更多</a></div>
        <div class="cutdv">其他</div>
        <div class="sbdv"><a target="_blank" href="/sitemap/index.php?mid=16" <?php if($moduleid==16) { ?>class="selected"<?php } ?>
>设备分类</a><a>资料下载</a><a href="<?php echo $MODULE['23']['linkurl'];?>" tarbl>专业名称</a><a href="<?php echo $MODULE['13']['linkurl'];?>" target="_blank">品牌检索</a></div>
    </div>
</div>
<!-- header<end>-->
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"slide":{"type":"slide","bdImg":"0","bdPos":"left","bdTop":"100"}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>