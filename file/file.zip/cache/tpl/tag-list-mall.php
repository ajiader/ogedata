<?php defined('IN_DESTOON') or exit('Access Denied');?> <?php if($showpage && $pages) { ?><div class="pages"><?php echo $pages;?></div><?php } ?>
    <table cellpadding="0" cellspacing="0" class="cptable">
    <tr class="tr1">
        <td width="76" class="td1">Compare<br />Parts</td>
            <td width="34"><img src="<?php echo DT_SKIN;?>/images/pdfiocn.gif" /></td>
            <td width="83">图片</td>
            <td width="121">产品名称</td>
            <td width="137">产品描述</td>
            <td width="137">件号</td>
            <td width="142">品牌</td>
           
            
        </tr>
    <?php if(is_array($tags)) { foreach($tags as $k => $t) { ?>
    <?php 
    $t['brand'] = getBrandName($t['brand_id']);
    // print_r($t['brand']);
    ?>
      <tr>
        <td class="td2"><input type="checkbox" id="check_<?php echo $t['itemid'];?>" name="itemid[]" value="<?php echo $t['itemid'];?>" onclick="sell_tip(this, <?php echo $t['itemid'];?>);"/></td>
            <td class="td2"><?php if($t['filepaths']) { ?><a href="<?php echo $t['filepaths'];?>" target="_blank"><img src="<?php echo DT_SKIN;?>/images/pdfiocn.gif" /></a><?php } else { ?><img src="<?php echo DT_SKIN;?>/images/pdfiocnh.gif" /><?php } ?>
</td>
            <td><a href="<?php echo $t['linkurl'];?>" target="_blank"><img class="lazy" src="<?php echo $t['thumb'];?>" width="70" alt="<?php echo $t['alt'];?>"/></a></td>
            <td><a href="<?php echo $t['linkurl'];?>" target="_blank"><strong class="px14"><?php echo $t['title'];?></strong></a></td>
            <td><?php echo $t['description'];?></td>
            <td><?php echo $t['jianhao'];?></td>
            <td align="center"><?php if($t['brand']['thumb']) { ?><a href="<?php echo $MODULE['13']['linkurl'];?><?php echo $t['brand']['linkurl'];?>"><img src="<?php echo $t['brand']['thumb'];?>" width="150"></a><a href="<?php echo $MODULE['13']['linkurl'];?><?php echo $t['brand']['linkurl'];?>"><?php echo $t['brand']['title'];?></a><?php } else { ?><a href="<?php echo $MODULE['13']['linkurl'];?><?php echo $t['brand']['linkurl'];?>"><?php echo $t['brand']['title'];?></a><?php } ?>
</td>
           
            
        </tr>
        <?php } } ?>
    </table>
    <?php if($showpage && $pages) { ?><div class="pages"><?php echo $pages;?></div><?php } ?>
