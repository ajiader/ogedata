<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header', $module);?>
<?php if($banner) { ?>
<div class="m"><a href="<?php echo $linkurl;?>"><img src="<?php echo $banner;?>" alt="<?php echo $title;?>"/></a></div>
<div class="m b10">&nbsp;</div>
<?php } ?>
<div class="m">
<div class="m_l f_l">
<div class="left_box">
<div class="pos">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <a href="<?php echo $linkurl;?>"><?php echo $title;?></a> &raquo; <?php echo $type['typename'];?></div>
<div class="catlist">
<?php echo tag("table=special_item&condition=specialid=$itemid and typeid=$typeid&order=addtime desc&pagesize=15&page=$page&showpage=1&datetype=5&target=_blank&template=list-cat&cols=5");?>
</div>
</div>
</div>
<div class="m_n f_l">&nbsp;</div>
<div class="m_r f_l">
<div class="box_head"><div><strong>推荐图文</strong></div></div>
<div class="box_body thumb"><?php echo tag("table=special_item&length=20&condition=specialid=$itemid and level=3 and thumb<>''&pagesize=4&order=addtime desc&width=120&height=90&cols=2&target=_blank&template=thumb-table", -2);?></div>
<div class="b10 c_b"> </div>
<div class="box_head"><div><strong>最新更新</strong></div></div>
<div class="box_body li_dot"><?php echo tag("table=special_item&condition=specialid=$itemid&order=addtime desc&pagesize=11&target=_blank, -2");?>
</div>
</div>
<div class="clear"></div>
</div>
<?php include template('footer');?>