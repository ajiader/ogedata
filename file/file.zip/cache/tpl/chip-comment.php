<?php defined('IN_DESTOON') or exit('Access Denied');?><?php if(in_array($moduleid, explode(',', $EXT['comment_module']))) { ?>
<div id="comment_div" style="display:;">
<div class="left_head"><span class="f_r"><a href="<?php echo $EXT['comment_url'];?><?php echo rewrite('index.php?mid='.$moduleid.'&itemid='.$itemid);?>">共<span id="comment_count">0</span>条 [查看全部]</a>&nbsp;&nbsp;</span>相关评论</div>
<div class="c_b" id="comment_main"><div></div></div>
</div>
<script type="text/javascript" src="<?php echo DT_STATIC;?>file/script/comment.js"></script>
<?php } ?>
