<?php defined('IN_DESTOON') or exit('Access Denied');?><?php include template('header');?>
<script type="text/javascript">var sh = '<?php echo $MOD['linkurl'];?>search.php?catid=<?php echo $catid;?>';</script>
<div class="m">
<div class="m_l f_l">
<div class="left_box">
<div class="pos">当前位置: <a href="<?php echo $MODULE['1']['linkurl'];?>">首页</a> &raquo; <a href="<?php echo $MOD['linkurl'];?>"><?php echo $MOD['name'];?></a> &raquo; <?php echo cat_pos($CAT, ' &raquo; ');?></div>
<?php if($CP) { ?>
<?php if(is_array($PPT)) { foreach($PPT as $p) { ?>
<div class="ppt">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="ppt_l" valign="top">按<?php echo $p['name'];?></td>
<td class="ppt_r" valign="top">
<?php if(is_array($p['options'])) { foreach($p['options'] as $o) { ?>
<a href="###" onclick="Go(sh+'&ppt_<?php echo $p['oid'];?>=<?php echo urlencode($o);?>');"><?php echo $o;?></a>&nbsp;|&nbsp;
<?php } } ?>
</td>
</tr>
</table>
</div>
<?php } } ?>
<div class="b10">&nbsp;</div>
<?php } ?>
<?php if($page == 1) { ?><?php echo ad($moduleid,$catid,$kw,6);?><?php } ?>
<?php if($tags) { ?><?php include template('list-'.$module, 'tag');?><?php } ?>
<br/>
</div>
</div>
<div class="m_n f_l">&nbsp;</div>
<div class="m_r f_l">
<div class="box_head"><div><strong>按行业浏览</strong></div></div>
<div class="box_body">
<div class="b5">&nbsp;</div>
<table width="100%" cellpadding="0" cellspacing="0">
<tr align="center">
<td width="20" height="20" class="tab_1_1">&nbsp;&nbsp;</td>
<td width="50" class="tab_1_2" id="cat_t_1" onmouseover="Tb(1, 2, 'cat', 'tab_1');">招聘</td>
<td width="50" class="tab_1_1" id="cat_t_2" onmouseover="Tb(2, 2, 'cat', 'tab_1');">求职</td>
<td class="tab_1_1">&nbsp;&nbsp;</td>
</tr>
</table>
<div class="b10">&nbsp;</div>
<div id="cat_c_1" style="display:">
<table width="100%" cellpadding="3">
<?php if(is_array($maincat)) { foreach($maincat as $k => $v) { ?>
<?php if($k%2==0) { ?><tr><?php } ?>
<td width="25%"><a href="<?php echo $MOD['linkurl'];?><?php echo $v['linkurl'];?>"><?php echo set_style($v['catname'],$v['style']);?></a><?php if(!$cityid) { ?> <span class="f_gray px10">(<?php echo $v['item'];?>)</span><?php } ?>
</td>
<?php if($k%2==1) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
<div id="cat_c_2" style="display:none;">
<table width="100%" cellpadding="3">
<?php if(is_array($maincat)) { foreach($maincat as $k => $v) { ?>
<?php if($k%2==0) { ?><tr><?php } ?>
<td width="25%"><a href="<?php echo $MOD['linkurl'];?><?php echo rewrite('search.php?action=resume&catid='.$v['catid']);?>" rel="nofollow"><?php echo set_style($v['catname'],$v['style']);?></a></td>
<?php if($k%2==1) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
</div>
<div class="b10 c_b">&nbsp;</div>
<div class="tab_head">
<ul>
<li class="tab_2" id="job_t_1" onmouseover="Tb(1, 2, 'job', 'tab');">职位搜索</li>
<li class="tab_1" id="job_t_2" onmouseover="Tb(2, 2, 'job', 'tab');">人才搜索</li>
</ul>
</div>
<div class="box_body">
<div id="job_c_1" style="display:">
<form action="<?php echo $MOD['linkurl'];?>search.php">
<input type="text" size="22" name="kw"/> 
<input type="submit" value="搜索"/>
<input type="button" value="高级" onclick="Go('<?php echo $MOD['linkurl'];?><?php echo rewrite('search.php?action=job');?>');"/>
</form>
</div>
<div id="job_c_2" style="display:none">
<form action="<?php echo $MOD['linkurl'];?>search.php">
<input type="hidden" name="action" value="resume"/>
<input type="text" size="22" name="kw"/>
<input type="submit" value="搜索"/>
<input type="button" value="高级" onclick="Go('<?php echo $MOD['linkurl'];?><?php echo rewrite('search.php?action=resume');?>');"/>
</form>
</div>
</div>
<div class="b10">&nbsp;</div>
<div class="box_head"><div><strong>按地区浏览</strong></div></div>
<div class="box_body">
<div class="b5">&nbsp;</div>
<table width="100%" cellpadding="0" cellspacing="0">
<tr align="center">
<td width="20" height="20" class="tab_1_1">&nbsp;&nbsp;</td>
<td width="50" class="tab_1_2" id="area_t_1" onmouseover="Tb(1, 2, 'area', 'tab_1');">招聘</td>
<td width="50" class="tab_1_1" id="area_t_2" onmouseover="Tb(2, 2, 'area', 'tab_1');">求职</td>
<td class="tab_1_1">&nbsp;&nbsp;</td>
</tr>
</table>
<div class="b10">&nbsp;</div>
<?php $mainarea = get_mainarea(0)?>
<div id="area_c_1" style="display:">
<table width="100%" cellpadding="3">
<?php if(is_array($mainarea)) { foreach($mainarea as $k => $v) { ?>
<?php if($k%4==0) { ?><tr><?php } ?>
<td><a href="<?php echo $MOD['linkurl'];?>search.php?areaid=<?php echo $v['areaid'];?>&catid=<?php echo $catid;?>" rel="nofollow"><?php echo $v['areaname'];?></a></td>
<?php if($k%4==3) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
<div id="area_c_2" style="display:none">
<table width="100%" cellpadding="3">
<?php if(is_array($mainarea)) { foreach($mainarea as $k => $v) { ?>
<?php if($k%4==0) { ?><tr><?php } ?>
<td><a href="<?php echo $MOD['linkurl'];?><?php echo rewrite('search.php?action=resume&areaid='.$v['areaid']);?>" rel="nofollow"><?php echo $v['areaname'];?></a></td>
<?php if($k%4==3) { ?></tr><?php } ?>
<?php } } ?>
</table>
</div>
</div>
</div>
</div>
<?php include template('footer');?>