<?php
$FILETYPE = array(
	'rar' => '压缩文件',
	'img' => '图片文件',
	'mov' => '音频/视频文件',
	'exe' => '应用程序',
	'pdf' => 'PDF文档',
	'doc' => 'Word文档',
	'xls' => 'Excel工作表',
	'ppt' => 'PPT幻灯片',
	'swf' => 'Flash影片',
	'chm' => 'CHM文件',
	'hlp' => '帮助文件',
	'oth' => '其他文件类型',
);
?>