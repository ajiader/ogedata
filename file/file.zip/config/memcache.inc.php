<?php
/*
说明:Memcache服务器配置
示例:
$MemServer = array(
	array('host'=>'192.168.1.10', 'port'=>'11211'),
	array('host'=>'192.168.1.11', 'port'=>'11211'),
	array('host'=>'192.168.1.12', 'port'=>'11211'),
);
*/
$MemServer = array(
	array('host'=>'127.0.0.1', 'port'=>'11211'),
);
?>