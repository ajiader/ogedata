<?php
/*
说明:下载模块镜像服务器配置
示例:
$MIRROR = array(
	array('name'=>'中国电信', 'url'=>'http://down1.destoon.com/'),
	array('name'=>'联通网通', 'url'=>'http://down2.destoon.com/'),
	array('name'=>'移动铁通', 'url'=>'http://down3.destoon.com/'),
);
*/
$MIRROR = array(
	#array('name'=>'Mirror Name', 'url'=>'http://mirror.destoon.com/'),
);
?>